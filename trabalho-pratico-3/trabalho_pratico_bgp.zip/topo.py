#!/usr/bin/python3
"""
topo.py – Topologia Mininet para o TP3
=======================================
Inicializa a rede com 4 roteadores FRR **sem nenhuma configuração BGP**.
Toda a configuração é injetada pelo Nornir (main.py).

Estrutura:
          h1 ─── s1 ─── r1
                          └─── r2 ─── s2 ─── h2
                               ├─── r3
                               └─── r4

Links e endereços (espelham o inventory/hosts.yaml):
  r1-eth1  203.0.1.1/24    (LAN s1)
  r2-eth1  203.0.2.1/24    (LAN s2)
  r1-eth2  203.0.12.1/30   ↔ r2-eth2  203.0.12.2/30
  r2-eth3  203.0.23.1/30   ↔ r3-eth1  203.0.23.2/30
  r2-eth4  203.0.24.1/30   ↔ r4-eth1  203.0.24.2/30
"""

import os
import subprocess
import time

from mininet.net import Mininet
from mininet.node import Node
from mininet.topo import Topo
from mininet.cli import CLI
from mininet.log import setLogLevel

# ─────────────────────────────────────────────────────────────
# Templates mínimos do FRR (sem BGP – Nornir cuida disso)
# ─────────────────────────────────────────────────────────────
DAEMONS = """
zebra=yes
bgpd=yes
vtysh_enable=yes
zebra_options=" -s 90000000 --daemon -A 127.0.0.1"
bgpd_options=" --daemon -A 127.0.0.1"
"""

VTYSH_CONF = """
hostname {name}
service integrated-vtysh-config
"""


# ─────────────────────────────────────────────────────────────
# SSH helpers (mantidos do original do professor)
# ─────────────────────────────────────────────────────────────
def cleanup_ssh():
    """Remove socat processes e diretórios temporários."""
    os.system("pkill -f 'socat TCP-LISTEN' >/dev/null 2>&1")
    os.system("rm -rf /tmp/r*")


def enable_ssh(net):
    """
    Habilita SSH para todos os hosts cujo nome começa com 'r'.
    Usa sshd isolado por namespace + socat para port-forward.
    Portas: r1→2201, r2→2202, r3→2203, r4→2204
    """
    print("\n*** Configurando SSH nos roteadores...")
    cleanup_ssh()

    routers = sorted(
        [h for h in net.hosts if h.name.startswith("r")],
        key=lambda x: int(x.name[1:]),
    )

    for r in routers:
        name = r.name
        num = int(name[1:])
        port = 2200 + num
        base = f"/tmp/{name}"

        print(f"  -> {name} na porta {port}")

        r.cmd(f"mkdir -p {base}/ssh {base}/run")

        # Host keys
        for key_type in ("rsa", "ecdsa", "ed25519"):
            r.cmd(
                f"ssh-keygen -t {key_type} -f {base}/ssh/ssh_host_{key_type}_key -N '' "
                f">/dev/null 2>&1"
            )

        # sshd_config isolada
        sshd_conf = f"""
Port {port}
Protocol 2
PermitRootLogin yes
PasswordAuthentication yes
UsePAM no
Subsystem sftp internal-sftp
PidFile {base}/run/sshd.pid
HostKey {base}/ssh/ssh_host_rsa_key
HostKey {base}/ssh/ssh_host_ecdsa_key
HostKey {base}/ssh/ssh_host_ed25519_key
"""
        r.cmd(f'echo "{sshd_conf}" > {base}/sshd_config')
        r.cmd("echo 'root:root' | chpasswd 2>/dev/null || echo -e 'root\\nroot' | passwd root 2>/dev/null")
        r.cmd(f"/usr/sbin/sshd -f {base}/sshd_config")

        # socat port-forward do namespace para o host
        pid = r.pid
        socat_cmd = (
            f"socat TCP-LISTEN:{port},fork "
            f"EXEC:\"nsenter -t {pid} -n nc 127.0.0.1 {port}\""
        )
        subprocess.Popen(socat_cmd, shell=True)

    print("\n*** SSH habilitado! Conecte com:")
    for r in routers:
        num = int(r.name[1:])
        print(f"    ssh -p {2200 + num} -o StrictHostKeyChecking=no root@127.0.0.1  # {r.name}")

    print("\n*** Para aplicar configurações BGP (em outro terminal):")
    print("    cd /caminho/do/tp3 && python3 main.py")
    print("\n*** Para encerrar socat:")
    print("    sudo pkill -f 'socat TCP-LISTEN'")


# ─────────────────────────────────────────────────────────────
# Classe FRR (nó com IP forwarding + FRR daemons)
# ─────────────────────────────────────────────────────────────
class FRR(Node):
    PrivateDirs = ["/etc/frr", "/var/run/frr"]

    def __init__(self, name, inNamespace=True, **params):
        params.setdefault("privateDirs", [])
        params["privateDirs"].extend(self.PrivateDirs)
        super().__init__(name, inNamespace=inNamespace, **params)

    def config(self, **params):
        super().config(**params)
        self.cmd("sysctl -w net.ipv4.ip_forward=1")
        self.cmd("ip link set lo up")
        self._start_frr()

    def _start_frr(self):
        """Sobe apenas zebra + bgpd, SEM configuração BGP."""
        self._set_conf("/etc/frr/daemons", DAEMONS)
        self._set_conf("/etc/frr/vtysh.conf", VTYSH_CONF.format(name=self.name))
        self.cmd("chown -R frr:frr /etc/frr/ 2>/dev/null || true")
        out = self.cmd("/usr/lib/frr/frrinit.sh start")
        print(f"  [FRR/{self.name}] {out.strip()}")

    def _set_conf(self, path, content):
        escaped = content.replace("'", "'\\''")
        self.cmd(f"printf '%s' '{escaped}' > {path}")

    def vtysh_cmd(self, cmd):
        """Executa comandos vtysh (usado para debug manual no CLI)."""
        lines = [l.strip() for l in cmd.splitlines() if l.strip()]
        args = " ".join(f'-c "{l}"' for l in lines)
        return self.cmd(f"vtysh {args}") if lines else ""


# ─────────────────────────────────────────────────────────────
# Topologia
# ─────────────────────────────────────────────────────────────
class SimpleTopo(Topo):
    def build(self):
        r1, r2, r3, r4 = [
            self.addHost(n, cls=FRR, ip=None) for n in ["r1", "r2", "r3", "r4"]
        ]
        s1, s2 = [
            self.addSwitch(s, failMode="standalone") for s in ["s1", "s2"]
        ]

        # LANs
        self.addLink(s1, r1, intfName2="r1-eth1", params2={"ip": "203.0.1.1/24"})
        self.addLink(s2, r2, intfName2="r2-eth1", params2={"ip": "203.0.2.1/24"})

        # Links inter-roteadores
        self.addLink(
            r1, r2,
            intfName1="r1-eth2", intfName2="r2-eth2",
            params1={"ip": "203.0.12.1/30"}, params2={"ip": "203.0.12.2/30"},
        )
        self.addLink(
            r2, r3,
            intfName1="r2-eth3", intfName2="r3-eth1",
            params1={"ip": "203.0.23.1/30"}, params2={"ip": "203.0.23.2/30"},
        )
        self.addLink(
            r2, r4,
            intfName1="r2-eth4", intfName2="r4-eth1",
            params1={"ip": "203.0.24.1/30"}, params2={"ip": "203.0.24.2/30"},
        )

        # Hosts finais
        h1 = self.addHost("h1", ip="203.0.1.100/24", defaultRoute="via 203.0.1.1")
        h2 = self.addHost("h2", ip="203.0.2.100/24", defaultRoute="via 203.0.2.1")
        self.addLink(h1, s1)
        self.addLink(h2, s2)


# ─────────────────────────────────────────────────────────────
# Entry-point
# ─────────────────────────────────────────────────────────────
def run():
    setLogLevel("info")
    net = Mininet(topo=SimpleTopo(), controller=None)

    print("\n*** Iniciando topologia (SEM config BGP – use o Nornir para configurar)")
    net.start()

    enable_ssh(net)

    # Pausa para o FRR iniciar completamente antes de abrir o CLI
    print("\n*** Aguardando FRR inicializar (5s)...")
    time.sleep(5)

    print("\n*** Topologia pronta! Abra outro terminal e execute:")
    print("    python3 main.py --step all\n")

    CLI(net)

    cleanup_ssh()
    net.stop()


if __name__ == "__main__":
    run()
