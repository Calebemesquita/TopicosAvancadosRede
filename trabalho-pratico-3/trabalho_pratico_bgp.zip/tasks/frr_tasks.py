"""
tasks/frr_tasks.py
==================
Tasks customizadas para o TP3 – Nornir + Fabric + FRR

Cada função segue a assinatura padrão do Nornir:
    def task_name(task: Task, ...) -> Result

Debug: passe DEBUG=True no ambiente ou use o logger do Nornir.
"""

import logging
import os
import time
from typing import Optional

from nornir.core.task import Task, Result
from nornir_utils.plugins.tasks.files import write_file
from nornir_jinja2.plugins.tasks import template_file
from nornir_paramiko.plugins.tasks import paramiko_command

# ---------- Logger dedicado ao TP3 ----------
log = logging.getLogger("tp3")
DEBUG = os.getenv("TP3_DEBUG", "0") == "1"


# ─────────────────────────────────────────────────────────────
# HELPER: executa vtysh e devolve saída limpa
# ─────────────────────────────────────────────────────────────
def _vtysh(task: Task, cmd: str) -> str:
    """Executa um bloco de comandos via vtysh no roteador remoto."""
    lines = [l.strip() for l in cmd.splitlines() if l.strip()]
    args = " ".join(f'-c "{l}"' for l in lines)
    full_cmd = f"vtysh {args}"

    if DEBUG:
        log.debug("[%s] vtysh_cmd: %s", task.host.name, full_cmd)

    result = task.run(
        task=paramiko_command,
        command=full_cmd,
        name=f"vtysh @ {task.host.name}",
    )
    return result.result


# ─────────────────────────────────────────────────────────────
# TASK 1 – Renderizar e salvar o config localmente
# ─────────────────────────────────────────────────────────────
def render_config(task: Task, template_dir: str = "templates") -> Result:
    """
    Renderiza o template Jinja2 frr_bgp.j2 com os dados do host
    e salva em configs/<hostname>.cfg para auditoria.
    """
    data = task.host.data

    rendered = task.run(
        task=template_file,
        template="frr_bgp.j2",
        path=template_dir,
        # variáveis expostas ao template (host removido por redundância)
        router_id=data["router_id"],
        asn=data["asn"],
        interfaces=data["interfaces"],
        bgp_neighbors=data["bgp_neighbors"],
        networks=data["networks"],
    )

    cfg_content = rendered.result
    cfg_path = f"configs/{task.host.name}.cfg"
    os.makedirs("configs", exist_ok=True)

    task.run(
        task=write_file,
        filename=cfg_path,
        content=cfg_content,
    )

    if DEBUG:
        log.debug("[%s] Config renderizada:\n%s", task.host.name, cfg_content)

    return Result(
        host=task.host,
        result=cfg_content,
        changed=False,
    )


# ─────────────────────────────────────────────────────────────
# TASK 2 – Aplicar configuração no roteador via vtysh
# ─────────────────────────────────────────────────────────────
def apply_config(task: Task, config: str) -> Result:
    """
    Envia o bloco de configuração ao FRR via vtysh.
    Retorna a saída do equipamento.
    """
    if DEBUG:
        log.debug("[%s] Aplicando config (tamanho=%d bytes)", task.host.name, len(config))

    output = _vtysh(task, config)

    changed = "Error" not in output and len(output.strip()) >= 0
    return Result(
        host=task.host,
        result=output,
        changed=changed,
    )


# ─────────────────────────────────────────────────────────────
# TASK 3 – Verificar estado BGP após configuração
# ─────────────────────────────────────────────────────────────
def verify_bgp(task: Task, template_dir: str = "templates") -> Result:
    """
    Renderiza verify_bgp.j2 para gerar os comandos show
    e os executa no roteador, devolvendo saída completa.
    """
    data = task.host.data

    rendered = task.run(
        task=template_file,
        template="verify_bgp.j2",
        path=template_dir,
        bgp_neighbors=data["bgp_neighbors"],
    )

    show_cmds = rendered.result
    output = _vtysh(task, show_cmds)

    if DEBUG:
        os.makedirs("debug_output", exist_ok=True)
        with open(f"debug_output/{task.host.name}_verify.txt", "w") as f:
            f.write(output)
        log.debug("[%s] Saída de verificação salva.", task.host.name)

    return Result(host=task.host, result=output, changed=False)


# ─────────────────────────────────────────────────────────────
# TASK 4 – Esperar FRR ficar pronto
# ─────────────────────────────────────────────────────────────
def wait_for_frr(task: Task, retries: int = 10, delay: float = 3.0) -> Result:
    """Aguarda o FRR/vtysh estar operacional no roteador."""
    probe_cmd = "show version"
    for attempt in range(1, retries + 1):
        try:
            output = _vtysh(task, probe_cmd)
            if "FRRouting" in output or "version" in output.lower():
                log.info("[%s] FRR pronto na tentativa %d/%d", task.host.name, attempt, retries)
                return Result(host=task.host, result=f"FRR pronto ({attempt} tentativas)", changed=False)
        except Exception as exc:
            if DEBUG:
                log.debug("[%s] Tentativa %d/%d falhou: %s", task.host.name, attempt, retries, exc)
        time.sleep(delay)

    msg = f"FRR não respondeu após {retries} tentativas em {task.host.name}"
    log.error(msg)
    return Result(host=task.host, result=msg, failed=True)


# ─────────────────────────────────────────────────────────────
# TASK 5 – Coletar show running-config
# ─────────────────────────────────────────────────────────────
def backup_running_config(task: Task) -> Result:
    """Coleta o running-config via vtysh e salva localmente."""
    output = _vtysh(task, "show running-config")
    os.makedirs("backups", exist_ok=True)
    path = f"backups/{task.host.name}_running.cfg"
    with open(path, "w") as f:
        f.write(output)

    log.info("[%s] Backup保存 em %s", task.host.name, path)
    return Result(host=task.host, result=output, changed=False)


# ─────────────────────────────────────────────────────────────
# TASK 6 – Ping de conectividade entre pares (smoke test)
# ─────────────────────────────────────────────────────────────
def ping_neighbors(task: Task) -> Result:
    """Executa ping para cada vizinho BGP configurado no host."""
    neighbors = task.host.data.get("bgp_neighbors", [])
    report = {}

    for nb in neighbors:
        ip = nb["peer_ip"]
        cmd = f"ping -c 3 -W 1 {ip}"
        result = task.run(task=paramiko_command, command=cmd, name=f"ping {ip}")
        output = result.result
        success = "3 received" in output or "3 packets transmitted, 3 received" in output
        report[ip] = {"neighbor": nb["peer_name"], "reachable": success, "output": output}

        if DEBUG:
            log.debug("[%s] ping %s → %s", task.host.name, ip, "OK" if success else "FALHOU")

    summary_lines = [f"  {ip}: {data['neighbor']} → {'✓' if data['reachable'] else '✗'}"
                     for ip, data in report.items()]
    summary = "\n".join(summary_lines)

    return Result(host=task.host, result=summary, changed=False)
