#!/usr/bin/env python3
"""
main.py – Orquestrador do TP3
==============================
Usa Nornir + SimpleInventory + Jinja2 + Paramiko para:
  1. Conectar nos 4 roteadores FRR via SSH (exposto pela topologia Mininet)
  2. Renderizar configs BGP via template Jinja2
  3. Aplicar configurações
  4. Verificar estado BGP
  5. Executar smoke-tests (ping entre vizinhos)
  6. Coletar backups do running-config

Variáveis de ambiente:
  TP3_DEBUG=1    → habilita logging detalhado (debug)
  TP3_HOSTS=r1,r3 → filtra apenas os hosts listados

Uso:
    python3 main.py [--step STEP] [--host HOST]

Passos disponíveis (--step):
  all         → executa tudo (padrão)
  wait        → aguarda FRR ficar pronto
  render      → só renderiza configs localmente
  deploy      → renderiza + aplica configs
  verify      → verifica BGP (show summary + routes)
  ping        → ping entre vizinhos
  backup      → coleta running-config de todos
"""

import argparse
import logging
import os
import sys
import time
from datetime import datetime

from nornir import InitNornir
from nornir.core.filter import F
from nornir_utils.plugins.functions import print_result

# Adiciona o diretório local ao path para importar tasks/
sys.path.insert(0, os.path.dirname(__file__))
from tasks.frr_tasks import (
    render_config,
    apply_config,
    verify_bgp,
    wait_for_frr,
    backup_running_config,
    ping_neighbors,
)

# ─────────────────────────────────────────────────────────────
# Configuração de logging
# ─────────────────────────────────────────────────────────────
DEBUG = os.getenv("TP3_DEBUG", "0") == "1"

logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format="%(asctime)s [%(levelname)-8s] %(name)s – %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("tp3.main")

# ─────────────────────────────────────────────────────────────
# Banner / utilidades de apresentação
# ─────────────────────────────────────────────────────────────
RESET  = "\033[0m"
BOLD   = "\033[1m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
BLUE   = "\033[94m"

def banner(msg: str, color: str = CYAN) -> None:
    width = 60
    line = "─" * width
    print(f"\n{color}{BOLD}{line}")
    print(f"  {msg}")
    print(f"{line}{RESET}\n")

def step_ok(name: str) -> None:
    print(f"{GREEN}  ✔  {name}{RESET}")

def step_fail(name: str) -> None:
    print(f"{RED}  ✘  {name}{RESET}")

def section(title: str) -> None:
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"\n{BLUE}{BOLD}[{ts}] ── {title}{RESET}")

# ─────────────────────────────────────────────────────────────
# Inicialização do Nornir
# ─────────────────────────────────────────────────────────────
def init_nornir(filter_hosts: list[str] | None = None):
    """Inicializa o Nornir com SimpleInventory e aplica filtro opcional."""
    nr = InitNornir(
        runner={
            "plugin": "threaded",
            "options": {"num_workers": 4},
        },
        inventory={
            "plugin": "SimpleInventory",
            "options": {
                "host_file":    "inventory/hosts.yaml",
                "group_file":   "inventory/groups.yaml",
                "defaults_file":"inventory/defaults.yaml",
            },
        },
        logging={
            "enabled": DEBUG,
            "level": "DEBUG" if DEBUG else "INFO",
            "log_file": "nornir_debug.log",
        },
    )

    # Filtro via --host ou TP3_HOSTS
    env_hosts = os.getenv("TP3_HOSTS", "")
    hosts_list = filter_hosts or ([h.strip() for h in env_hosts.split(",") if h.strip()])

    if hosts_list:
        nr = nr.filter(F(name__any=hosts_list))
        log.info("Filtrando hosts: %s", hosts_list)

    log.info("Hosts carregados: %s", list(nr.inventory.hosts.keys()))
    return nr

# ─────────────────────────────────────────────────────────────
# Funções de steps individuais
# ─────────────────────────────────────────────────────────────

def step_wait(nr) -> bool:
    section("Aguardando FRR ficar pronto em todos os roteadores...")
    result = nr.run(task=wait_for_frr, retries=12, delay=3.0)
    print_result(result)
    failed = [h for h, r in result.items() if r.failed]
    if failed:
        step_fail(f"FRR não respondeu em: {failed}")
        return False
    step_ok("Todos os roteadores com FRR pronto.")
    return True


def step_render(nr) -> dict:
    """Renderiza configs e devolve dict {hostname: config_text}."""
    section("Renderizando configurações via Jinja2...")
    result = nr.run(task=render_config, template_dir="templates")
    print_result(result)

    configs = {}
    for host, multi in result.items():
        # O MultiResult tem o resultado do render_config na posição 0
        # e sub-tasks (template_file, write_file) nas seguintes
        cfg = multi[0].result
        if cfg:
            configs[host] = cfg
            step_ok(f"{host}: config renderizada ({len(cfg)} bytes) → configs/{host}.cfg")
        else:
            step_fail(f"{host}: falha na renderização")
    return configs


def step_deploy(nr, configs: dict) -> bool:
    """Aplica os configs renderizados em cada roteador."""
    section("Aplicando configurações nos roteadores via SSH/vtysh...")

    all_ok = True
    for host_name, cfg in configs.items():
        host_nr = nr.filter(F(name=host_name))
        result = host_nr.run(
            task=apply_config,
            config=cfg,
        )
        print_result(result)
        r = result[host_name]
        if r.failed or (r.result and "Error" in r.result):
            step_fail(f"{host_name}: erro ao aplicar config")
            all_ok = False
        else:
            step_ok(f"{host_name}: config aplicada com sucesso")

    return all_ok


def step_verify(nr) -> None:
    section("Verificando estado BGP (show summary + routes)...")
    result = nr.run(task=verify_bgp, template_dir="templates")
    print_result(result)

    for host, multi in result.items():
        output = multi[0].result or ""
        # Heurística simples: procura "Established" nas sessões BGP
        established = output.count("Established")
        expected = len(nr.inventory.hosts[host].data.get("bgp_neighbors", []))
        if established >= expected:
            step_ok(f"{host}: {established}/{expected} sessões BGP Established")
        else:
            step_fail(f"{host}: apenas {established}/{expected} sessões BGP Established")
            if DEBUG:
                log.debug("[%s] Saída BGP:\n%s", host, output)


def step_ping(nr) -> None:
    section("Smoke-test: ping entre vizinhos BGP...")
    result = nr.run(task=ping_neighbors)
    print_result(result)

    for host, multi in result.items():
        output = multi[0].result or ""
        # Verifica se algum vizinho falhou
        if "✗" in output:
            step_fail(f"{host}:\n{output}")
        else:
            step_ok(f"{host}: todos os vizinhos alcançáveis")


def step_backup(nr) -> None:
    section("Coletando backup do running-config...")
    result = nr.run(task=backup_running_config)
    print_result(result)
    for host in result:
        step_ok(f"{host}: backup salvo em backups/{host}_running.cfg")

# ─────────────────────────────────────────────────────────────
# Fluxo principal
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="TP3 – Nornir + FRR BGP Orchestrator")
    parser.add_argument(
        "--step",
        choices=["all", "wait", "render", "deploy", "verify", "ping", "backup"],
        default="all",
        help="Qual etapa executar (padrão: all)",
    )
    parser.add_argument(
        "--host",
        nargs="*",
        help="Filtrar hosts específicos (ex: --host r1 r3)",
    )
    args = parser.parse_args()

    banner("TP3 – Nornir + Jinja2 + FRR BGP Configurator", CYAN)
    print(f"  Passo selecionado : {BOLD}{args.step}{RESET}")
    print(f"  Filtro de hosts   : {args.host or 'todos'}")
    print(f"  Modo debug        : {'ATIVO' if DEBUG else 'desativado'} (TP3_DEBUG={os.getenv('TP3_DEBUG','0')})")

    nr = init_nornir(filter_hosts=args.host)

    start = time.time()

    try:
        if args.step in ("all", "wait"):
            ok = step_wait(nr)
            if not ok and args.step == "all":
                log.error("Abortando: FRR não está pronto.")
                sys.exit(1)

        configs = {}
        if args.step in ("all", "render", "deploy"):
            configs = step_render(nr)

        if args.step in ("all", "deploy"):
            if not configs:
                log.warning("Nenhum config renderizado. Pulando deploy.")
            else:
                step_deploy(nr, configs)
                # Pequena pausa para o BGP convergir
                wait_seconds = 15
                section(f"Aguardando {wait_seconds}s para convergência BGP...")
                time.sleep(wait_seconds)

        if args.step in ("all", "verify"):
            step_verify(nr)

        if args.step in ("all", "ping"):
            step_ping(nr)

        if args.step in ("all", "backup"):
            step_backup(nr)

    except KeyboardInterrupt:
        print(f"\n{YELLOW}Interrompido pelo usuário.{RESET}")
        sys.exit(130)

    elapsed = time.time() - start
    banner(f"Concluído em {elapsed:.1f}s", GREEN)


if __name__ == "__main__":
    main()
